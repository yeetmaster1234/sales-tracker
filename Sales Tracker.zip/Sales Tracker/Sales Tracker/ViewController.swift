//
//  ViewController.swift
//  Sales Tracker
//
//  Created by Spencer Kane on 8/3/19.
//  Copyright © 2019 Spencer Kane. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
   
    @IBOutlet weak var platformPicker: UIPickerView!
    var pickerData: [String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
        self.platformPicker.delegate = self
        self.platformPicker.dataSource = self
        
        pickerData = ["StockX", "Goat", "Grailed", "Other(No Fees)"]
            // Do any additional setup after loading the view.
        }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return pickerData[row]
        }
    
    }



