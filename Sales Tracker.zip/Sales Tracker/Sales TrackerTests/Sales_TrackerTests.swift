//
//  Sales_TrackerTests.swift
//  Sales TrackerTests
//
//  Created by Spencer Kane on 8/3/19.
//  Copyright © 2019 Spencer Kane. All rights reserved.
//

import XCTest
@testable import Sales_Tracker

class Sales_TrackerTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
